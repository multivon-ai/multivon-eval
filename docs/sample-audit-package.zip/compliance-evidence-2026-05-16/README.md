# Compliance Evidence Package

**Suite:** eu-ai-act-eval
**Framework:** eu-ai-act
**Period:** 2026-05-16
**Package format:** 1.0.0
**Built by:** multivon-eval 0.7.0
**Generated:** 2026-05-16T10:18:13+00:00

## What's in this archive

- `audit_log.ndjson` — Append-only NDJSON log produced by
  `ComplianceReporter`. Every entry is part of a SHA-256 hash chain;
  see `verify.py` to recompute it.
- `calibration_v2.json` — The per-judge threshold table that drove the
  evaluator decisions in the audit log, with dataset hashes, N, F1,
  and measurement dates.
- `coverage_report.md` — Catalog of the framework's measurable and
  process controls.
- `verify.py` — Standalone Python script. Run `python verify.py` from
  inside this directory to recompute every file's SHA-256 and walk the
  hash chain. Exits 0 on success, non-zero on any failure.
- `manifest.json` — Machine-readable inventory with SHA-256 of every
  other file in the package.

## How to verify

```bash
unzip evidence-2026-05-16.zip
cd compliance-evidence-2026-05-16
python verify.py
```

Expected output ends with `VERIFICATION PASSED`. Any line beginning
with `FAIL` is an integrity finding the auditor should investigate.

## Scope and limits

multivon-eval evaluators provide *measurable* evidence. Process
controls (technical documentation, transparency, human oversight,
administrative safeguards, BAAs) require organizational measures that
this package cannot demonstrate. See `coverage_report.md` for the
distinction.
