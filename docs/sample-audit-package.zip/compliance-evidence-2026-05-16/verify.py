#!/usr/bin/env python3
"""
Verifier for a multivon-eval Compliance Evidence Package.

Run alongside the package contents::

    python verify.py

Checks:
  1. Every file's SHA-256 matches the manifest.
  2. The audit log's hash chain is intact end-to-end.
  3. The package format version is one this script can read.

Exits 0 on success, non-zero on the first failure encountered. Auditors
should keep this script with the package contents.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    manifest_path = HERE / "manifest.json"
    if not manifest_path.exists():
        print("FAIL: manifest.json missing", file=sys.stderr)
        return 2
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    fmt = manifest.get("package_format_version")
    if fmt != "1.0.0":
        print(f"FAIL: unknown package_format_version {fmt!r}", file=sys.stderr)
        return 3

    # 1) Recompute every file's SHA-256.
    errors = 0
    for entry in manifest["files"]:
        path = HERE / entry["path"]
        if not path.exists():
            print(f"FAIL  missing  {entry['path']}", file=sys.stderr)
            errors += 1
            continue
        actual = sha256(path.read_bytes())
        if actual != entry["sha256"]:
            print(f"FAIL  hash     {entry['path']}", file=sys.stderr)
            errors += 1
        else:
            print(f"OK    hash     {entry['path']}")

    # 2) Walk the audit log chain.
    log_relpath = manifest.get("audit_log")
    if log_relpath:
        prev_expected = "0" * 64
        log = HERE / log_relpath
        for i, line in enumerate(log.read_text(encoding="utf-8").splitlines()):
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            stored = data.pop("record_hash")
            recomputed = sha256(json.dumps(data, separators=(",", ":")).encode())
            if recomputed != stored:
                print(f"FAIL  chain    record {i} hash mismatch", file=sys.stderr)
                errors += 1
                prev_expected = "0" * 64
                continue
            chain_v = data.get("chain_version")
            if chain_v is not None:
                if data.get("prev_hash") != prev_expected:
                    print(f"FAIL  chain    record {i} prev_hash mismatch", file=sys.stderr)
                    errors += 1
                else:
                    print(f"OK    chain    record {i}")
            else:
                print(f"OK    legacy   record {i}")
            prev_expected = recomputed

    if errors:
        print(f"\nVERIFICATION FAILED: {errors} error(s)", file=sys.stderr)
        return 1
    print("\nVERIFICATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
