# Compliance coverage — eu-ai-act

Suite: eu-ai-act-eval
Generated: 2026-05-16T10:18:13+00:00

## Measurable controls

- **Art. 9(2)(b)** — Foreseeable misuse risk identification
- **Art. 10(2)(f-g)** — Examination and mitigation of possible biases
- **Art. 10(5)** — Processing of personal data
- **Art. 15(1)** — Accuracy
- **Art. 15(2)** — Robustness

## Process controls (require organizational measures, not satisfiable by evaluators)

- **Art. 11** — Technical documentation
- **Art. 12** — Record-keeping (satisfied by this reporter)
- **Art. 13** — Transparency and information to deployers
- **Art. 14** — Human oversight
- **Art. 15(4-5)** — Cybersecurity and resilience