---
name: eval-bootstrap
description: |
  Auto-generate an evaluation suite for an LLM-touching codebase using
  multivon-eval. Reads the project description + sample traces, picks
  candidate evaluators, suggests provisional thresholds, emits a runnable
  eval_suite.py + up to 30 accepted synthetic seed cases + EVALS.md.

  Invoke when the user says "add evals to this project", "set up
  evaluation", "eval this codebase", "evaluate this project", or "what
  evaluators should I run" — or when you detect an LLM-touching project
  (imports from anthropic/openai/google/litellm) with no existing
  eval/ or tests/eval/ directory.

  Provides: the multivon-eval bootstrap workflow, an EVALS.md scaffold,
  and an eval_suite.py with stub_model replaced by the detected provider.

  Requires: multivon-eval >= 0.9.8 (pip install multivon-eval) and
  either an ANTHROPIC_API_KEY / OPENAI_API_KEY / GOOGLE_API_KEY in env,
  OR a running Ollama instance for fully local bootstrap.
allowed-tools: Bash, Read, Edit, Write, Glob
---

# eval-bootstrap

Turns a one-paragraph product description + a handful of sample traces
into a runnable eval suite, so a fresh project can go from no eval
scaffolding to a first runnable eval for review.

## When to invoke

Auto-invoke if:
- The user explicitly asks for evals ("add evals", "set up evaluation",
  "eval this codebase", "evaluate this project", "what evaluators
  should I run").
- The current repo imports from `anthropic`, `openai`, `google.genai`,
  `litellm`, `langchain`, or `llama_index` AND has no `eval/`,
  `evals/`, `tests/eval/`, or `evaluation/` directory.
- The user is reviewing a PR that touches prompts/system-messages/
  model parameters AND there's no eval gate on the repo (use
  `/eval-audit` instead if evals already exist — see that skill).

Do NOT auto-invoke if:
- The repo already has an `eval/` directory with a working suite
  (suggest `/eval-audit` instead).
- The user is in the middle of a different task and you'd be
  context-switching them.

## What the skill does

1. **Scope check** — read `pyproject.toml` / `package.json` to identify
   the LLM provider in use. If multiple, ask the user which to target.
2. **Trace collection** — find sample traces. Check, in order:
   - `traces/*.jsonl` or `data/traces/*.jsonl` in the repo
   - `notebooks/*/traces.jsonl`
   - Ask the user to paste 5-20 sample (input, output) pairs into a
     temp file
   If the project uses LangSmith / LangFuse / Phoenix, prompt for a
   dump command (the user typically runs this themselves — these are
   their secrets).
3. **Product description** — if the repo has `PRODUCT.md`,
   `OVERVIEW.md`, or a top-level README, use that as the product
   description. Otherwise ask the user for 2-3 sentences describing
   what their LLM does.
4. **Run bootstrap** — execute (in a fresh terminal the user can
   inspect):
   ```bash
   multivon-eval bootstrap \
       --product PRODUCT.md \
       --traces sample_traces.jsonl \
       --output ./eval-bootstrap \
       --judge-provider <detected_provider> \
       --judge-model <sensible_default> \
       --pii-policy redact
   ```
   The bootstrap CLI emits four files in the output directory: `eval_suite.py` (runnable),
   `seed_cases.jsonl` (up to 30 accepted synthetic cases), `thresholds.yaml`
   (provisional p25 score thresholds; not human-labeled calibration), `DISCOVERY_REPORT.md` (rationale for
   each evaluator). It also writes `prompt_baseline.json` at the
   repository root for staleness checks.
5. **Rewrite `stub_model`** — `eval_suite.py` ships with a placeholder
   `stub_model()` function. Replace it with a real call into the
   project's model — read 1-2 of the project's existing LLM call sites
   to copy the pattern (don't reinvent client setup; reuse what's
   there).
6. **Write `EVALS.md`** — a short doc the next Claude Code session
   reads first. Include:
   - What evaluators were picked and why (1 sentence each)
   - The CLI command to re-run the suite
   - The CI wiring TODO (link to `/eval-audit` skill for PR gating)
7. **Sanity-check** — run `python eval_suite.py --runs 1` once. If it
   fails, inspect whether the cause is configuration, the grader, or model
   quality. Do not infer the cause merely from an early failure.

## Local-judge path (no API key)

If no cloud API key is in env, check for a running Ollama instance
(`curl -s http://localhost:11434/api/tags`). If present, run `ollama list`
first to see what the user has actually pulled, then pick the strongest
instruction-tuned model available. Examples to review against the task (not a measured ranking): `qwen2.5:72b`, `llama3.3:70b-instruct`, `deepseek-r1:32b`,
`qwen2.5:14b`. Pass it via `--judge-model`:

```bash
ollama list                                          # see what's available
multivon-eval bootstrap \
    --product PRODUCT.md \
    --traces sample_traces.jsonl \
    --judge-provider ollama \
    --judge-model <picked_model>                     # e.g. qwen2.5:72b
```

Local bootstrap can run without hosted calls when Ollama and the selected
model are already available. Runtime depends on local hardware. Cloud-judge
threshold packs do not validate a local judge; unmatched models use fallback
thresholds. Bootstrap's p25 suggestions are not labeled calibration. Recommend
reviewing human-labeled examples, choosing thresholds on a development split,
and checking a separate test split. `suite.calibrate()` measures agreement but
does not fit thresholds.

## What it doesn't do

- Doesn't promise the generated suite covers everything the project
  should evaluate. It covers the shape it can infer from traces and
  the product description. Treat it as a starting point.
- Doesn't replace `pytest` or the project's existing test suite.
- Doesn't ship a hosted dashboard — output is plain JSON + markdown
  + runnable Python.
- Doesn't gate PRs by itself — pair with `eval-action` (GitHub
  Action) for CI gating.

## Costs

Cost depends on model pricing and calls. `--budget-usd` checks estimated
seed-generation cost only; it does not cap total bootstrap or validation spend.
Local Ollama avoids hosted API charges but uses local compute.

## Verification

Confirm the bootstrap worked by:
```bash
ls eval-bootstrap/
# expect: eval_suite.py  seed_cases.jsonl  thresholds.yaml  DISCOVERY_REPORT.md
test -f prompt_baseline.json
python eval-bootstrap/eval_suite.py --runs 1
```

If the user wants this wired into CI gating, suggest installing the
[multivon-ai/eval-action GitHub repo](https://github.com/multivon-ai/eval-action)
(Marketplace listing pending — use the repo directly for now).
