from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class ToolCall:
    """A single tool/function call made by an agent."""
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    result: Any = None


@dataclass
class AgentStep:
    """One step in an agent's execution trace."""
    thought: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    output: str = ""


@dataclass
class EvalCase:
    """
    A single test case for evaluation.

    Attributes:
        input:                The prompt, question, or user message.
        expected_output:      Ideal response (used by ExactMatch, AnswerAccuracy).
        context:              Retrieved documents or context (used by Faithfulness, Hallucination).
        conversation:         Multi-turn message history for conversation evaluators.
                              Format: [{"role": "user"/"assistant", "content": "..."}]
        agent_trace:          Sequence of agent steps for agent evaluators.
        expected_tool_calls:  Ordered list of tool names the agent should call.
        metadata:             Arbitrary key-value data (e.g. source_id, difficulty).
        tags:                 Labels for filtering reports.
        reference_output:     Known-good output used ONLY by ``multivon-eval
                              validate`` to grade the graders (falls back to
                              expected_output). May be a callable invoked at
                              validate time. Deliberately EXCLUDED from the
                              suite lockfile's cases_hash so adding it never
                              invalidates historical locks.
    """
    input: str
    expected_output: str | None = None
    context: str | list[str] | None = None
    conversation: list[dict[str, str]] | None = None
    agent_trace: list[AgentStep] | None = None
    expected_tool_calls: list[str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    reference_output: str | Callable[["EvalCase"], str] | None = None
    case_id: str | None = None
    revision: str | None = None
    source_id: str | None = None

    def identity(self) -> tuple[str, str]:
        """Return stable ID and content digest; explicit IDs survive revisions.

        Without an explicit ID, the content digest supplies the ID. Runtime
        mutation changes the digest, so runners capture it before execution.
        Callable validation-only reference outputs do not enter this digest.
        """
        from .case_manifest import case_identity
        return case_identity(self)

    def context_str(self) -> str:
        if self.context is None:
            return ""
        if isinstance(self.context, list):
            return "\n\n".join(self.context)
        return self.context

    def conversation_str(self) -> str:
        if not self.conversation:
            return ""
        return "\n".join(f"{m['role'].upper()}: {m['content']}" for m in self.conversation)
