from __future__ import annotations
import json
import csv
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TYPE_CHECKING
from .trials import TrialRecord
from .case_manifest import trace_from_data, trace_to_data

if TYPE_CHECKING:
    from .passk import PassKResult


class EvalStatus(str, Enum):
    """Terminal status of a case after running the suite.

    Subclasses :class:`str` so the value is JSON-serializable as-is, and so
    ``status == "passed"`` works without unwrapping.

    The split between quality-level outcomes (``PASSED`` / ``FAILED_QUALITY``)
    and infrastructure-level outcomes (``MODEL_ERROR`` / ``JUDGE_ERROR`` /
    ``EVALUATOR_ERROR`` / ``TIMEOUT`` / ``SKIPPED``) is load-bearing — error
    cases are excluded from ``pass_rate`` and ``avg_score`` so a transient
    judge outage doesn't masquerade as a model regression.
    """
    PASSED = "passed"
    FAILED_QUALITY = "failed_quality"
    MODEL_ERROR = "model_error"
    JUDGE_ERROR = "judge_error"
    EVALUATOR_ERROR = "evaluator_error"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


# Statuses that count as a real, completed quality measurement. Anything
# else is plumbing — excluded from pass_rate / avg_score denominators.
EVALUATION_STATUSES = frozenset({EvalStatus.PASSED, EvalStatus.FAILED_QUALITY})

# Statuses that indicate something went wrong below the model/quality layer.
ERROR_STATUSES = frozenset({
    EvalStatus.MODEL_ERROR, EvalStatus.JUDGE_ERROR,
    EvalStatus.EVALUATOR_ERROR, EvalStatus.TIMEOUT,
})


# Characters that XML 1.0 declares illegal in document content, even when
# escaped. Strict parsers (most CI consumers) reject the whole document
# if any of these appear. Strip them before they touch the XML serializer.
_XML_INVALID_CHARS = "".join(
    chr(c) for c in range(0x20)
    if c not in (0x09, 0x0A, 0x0D)   # tab, newline, carriage return are allowed
) + "￾￿"
_XML_INVALID_TRANS = str.maketrans({c: "" for c in _XML_INVALID_CHARS})


def _xml_safe(s: str) -> str:
    """Return ``s`` with XML 1.0-invalid control characters removed.

    Evaluator reasons can pull from agent traces, raw API errors, or
    user output that occasionally contains \\x00 / \\x08 / etc. — those
    would break a strict JUnit consumer downstream. Sanitizing once at
    the serialization boundary keeps the XML well-formed.
    """
    if not isinstance(s, str):
        s = str(s)
    return s.translate(_XML_INVALID_TRANS)


@dataclass
class EvalResult:
    """Result of a single evaluator on a single case."""
    evaluator: str
    score: float          # 0.0 – 1.0
    passed: bool
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class EvalGateFailure(Exception, SystemExit):
    """
    Raised when a gate on the run fails (pass_rate, budget, etc.).

    Inherits from BOTH ``Exception`` and ``SystemExit`` so:
      - Library callers can catch with ``except Exception`` or ``except
        EvalGateFailure`` and inspect the report before deciding what to
        do (e.g., in notebooks or test harnesses).
      - CI scripts that leave the exception uncaught still get clean
        process-exit semantics (non-zero exit code, no Python traceback
        noise) — Python's default unhandled-exception handler treats it
        as a SystemExit and prints just the message to stderr.

    Users running ``report.assert_budget()`` inside their own ``except
    Exception`` blocks couldn't catch the violation under the
    SystemExit-only base class that shipped through 0.8.2.

    pass_rate and threshold are set for pass-rate gate failures and may be
    None for other gate types (e.g., budget violations).
    """
    def __init__(self, message: str, pass_rate: float | None = None,
                 threshold: float | None = None) -> None:
        # ``Exception.__init__`` (the first base in the MRO) populates
        # ``args`` but does not initialise ``SystemExit.code``.  An uncaught
        # instance therefore used to terminate Python with status 0 — exactly
        # the opposite of what a CI gate promises.  Keep the Exception
        # catchability while explicitly giving SystemExit a non-empty code;
        # Python prints the message without a traceback and exits 1.
        Exception.__init__(self, message)
        self.code = message
        self.pass_rate = pass_rate
        self.threshold = threshold


@dataclass
class CaseResult:
    """All evaluator results for a single test case."""
    case_input: str
    actual_output: str
    results: list[EvalResult]
    latency_ms: float = 0.0
    tags: list[str] = field(default_factory=list)
    model_error: str | None = None  # set when the model call raised an exception
    judge_error: str | None = None  # set when a judge call raised (transient/auth/etc)
    evaluator_error: str | None = None  # set when an evaluator itself raised (bug)
    skipped: bool = False  # set when the case was deliberately skipped (e.g. tag-filter)
    # ``agent_trace`` is populated when the suite was run with a tracer.
    # Exposed on CaseResult (not just EvalCase) so notebooks can iterate the
    # captured steps from the report without reaching back into the suite.
    agent_trace: list[Any] | None = None  # list[AgentStep] when set; Any to avoid circular import

    # Multi-run fields — populated when suite.run(runs > 1)
    runs: int = 1
    all_scores: list[float] = field(default_factory=list)   # one score per run
    pass_count: int = -1  # -1 = single run (not tracked)

    # Retry history — populated when suite.run(judge_retry=JudgeRetry(...))
    # encountered a retriable status (judge_error by default) and re-ran
    # the case. ``retry_attempts`` counts the number of RETRIES that
    # actually happened (0 = no retry needed, max_attempts - 1 =
    # exhausted). ``retry_errors`` holds the error message from each
    # failed attempt THAT PROMPTED a retry — the final attempt's
    # failure (if any) is reflected in ``judge_error`` / ``status``
    # instead, not duplicated here. So ``len(retry_errors) ==
    # retry_attempts`` always.
    retry_attempts: int = 0
    retry_errors: list[str] = field(default_factory=list)
    case_id: str | None = None
    case_digest: str | None = None
    trials: tuple[TrialRecord, ...] = ()
    evidence_error: str | None = None

    @property
    def status(self) -> "EvalStatus":
        """High-level outcome of the case.

        Order of precedence (highest → lowest):
          1. Plumbing failures (skipped → model_error → judge_error → evaluator_error)
          2. Quality outcome (passed if all evaluators passed, else failed_quality)

        Used by :attr:`EvalReport.pass_rate` to exclude error cases from the
        denominator — a transient judge outage shouldn't drag pass_rate down
        as if the model regressed.
        """
        if self.skipped:
            return EvalStatus.SKIPPED
        if self.model_error is not None:
            return EvalStatus.MODEL_ERROR
        if self.judge_error is not None:
            return EvalStatus.JUDGE_ERROR
        if self.evaluator_error is not None:
            return EvalStatus.EVALUATOR_ERROR
        # No infrastructure failure → fall through to quality outcome.
        measured = [r for r in self.results if not r.metadata.get("skipped")]
        if self.results and not measured:
            return EvalStatus.SKIPPED
        if self.pass_count >= 0:
            return EvalStatus.PASSED if self.pass_count == self.runs else EvalStatus.FAILED_QUALITY
        all_passed = bool(measured) and all(r.passed for r in measured)
        return EvalStatus.PASSED if all_passed else EvalStatus.FAILED_QUALITY

    @property
    def passed(self) -> bool:
        """Whether this case is a clean pass.

        Defined as ``status == EvalStatus.PASSED`` so the two views always
        agree. A case with NO evaluator results is not a pass — there's
        nothing to prove it succeeded, and ``status`` classifies it as
        ``FAILED_QUALITY``. A case in any error state (model/judge/
        evaluator/timeout) is not a pass even if individual evaluator
        results were collected before the error fired.
        """
        return self.status == EvalStatus.PASSED

    @property
    def score(self) -> float:
        if self.all_scores:
            return sum(self.all_scores) / len(self.all_scores)
        measured = [r for r in self.results if not r.metadata.get("skipped")]
        if not measured:
            return 0.0
        return sum(r.score for r in measured) / len(measured)

    @property
    def score_std(self) -> float:
        if len(self.all_scores) < 2:
            return 0.0
        mean = self.score
        return math.sqrt(sum((s - mean) ** 2 for s in self.all_scores) / len(self.all_scores))

    @property
    def run_pass_rate(self) -> float:
        """Fraction of runs that passed. 1.0 when runs=1."""
        if self.pass_count < 0:
            return 1.0 if self.passed else 0.0
        return self.pass_count / self.runs if self.runs > 0 else 0.0

    @property
    def is_flaky(self) -> bool:
        """True if the case sometimes passes and sometimes fails across runs."""
        if self.runs <= 1 or self.pass_count < 0:
            return False
        return 0 < self.pass_count < self.runs


@dataclass
class CalibrationResult:
    """Judge accuracy against human-labeled ground truth."""
    n: int
    agreement: float
    precision: float
    recall: float
    f1: float
    by_evaluator: dict[str, dict[str, float]] = field(default_factory=dict)

    def __str__(self) -> str:
        lines = [
            f"Judge Calibration — {self.n} labeled cases",
            f"  Agreement:  {self.agreement:.1%}",
            f"  Precision:  {self.precision:.1%}",
            f"  Recall:     {self.recall:.1%}",
            f"  F1 Score:   {self.f1:.1%}",
        ]
        if self.by_evaluator:
            lines.append("  By evaluator:")
            for ev, stats in self.by_evaluator.items():
                lines.append(f"    {ev}: agreement={stats['agreement']:.1%}  F1={stats['f1']:.1%}")
        return "\n".join(lines)


@dataclass
class PairwiseResult:
    """Pairwise judge verdict for one case."""
    case_input: str
    output_a: str
    output_b: str
    winner: str   # "A", "B", or "Tie"
    reason: str = ""


@dataclass
class PairwiseReport:
    """Aggregated results from suite.run_pairwise()."""
    suite_name: str
    model_a_id: str
    model_b_id: str
    results: "list[PairwiseResult]"

    @property
    def wins_a(self) -> int:
        return sum(1 for r in self.results if r.winner == "A")

    @property
    def wins_b(self) -> int:
        return sum(1 for r in self.results if r.winner == "B")

    @property
    def ties(self) -> int:
        return sum(1 for r in self.results if r.winner == "Tie")

    @property
    def total(self) -> int:
        return len(self.results)

    def p_value(self) -> float:
        """Sign test p-value (H0: wins_a == wins_b, ties excluded)."""
        n = self.wins_a + self.wins_b
        if n == 0:
            return 1.0
        stat = (abs(self.wins_a - self.wins_b) - 1) ** 2 / n
        from .experiments import _norm_cdf
        return 2 * (1 - _norm_cdf(math.sqrt(stat)))

    def __str__(self) -> str:
        p = self.p_value()
        sig = "significant" if p < 0.05 else "not significant"
        label_a = self.model_a_id or "Model A"
        label_b = self.model_b_id or "Model B"
        if self.wins_a > self.wins_b:
            verdict = label_a
        elif self.wins_b > self.wins_a:
            verdict = label_b
        else:
            verdict = "Tie"
        return (
            f"Pairwise: {label_a} vs {label_b}  ({self.total} cases)\n"
            f"  {label_a} wins: {self.wins_a}  "
            f"{label_b} wins: {self.wins_b}  Ties: {self.ties}\n"
            f"  Verdict: {verdict}  (p={p:.3f}, {sig})"
        )


@dataclass
class EvalReport:
    """Aggregated results for an entire eval suite run."""
    suite_name: str
    case_results: list[CaseResult]
    model_id: str = ""
    judge_reliability: float | None = None
    costs: Any = None  # multivon_eval.costs.Costs or None; populated by suite.run()
    # Content-addressed fingerprint of the suite that produced this report.
    # Populated by ``EvalSuite.run`` at run-time so audit log records can
    # capture the EXACT evaluator + case state that drove the decisions.
    # See :class:`multivon_eval.lockfile.SuiteLock` for the schema.
    suite_lock: Any = None  # SuiteLock | None — Any avoids the circular import
    # Declared intent of the suite: '' (unset) | 'capability' | 'regression'.
    # Drives the saturation-monitor messaging: a capability suite at 100%
    # gets a graduation nudge; a regression suite inverts the warning.
    purpose: str = ""
    evidence_issues: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.case_results)

    @property
    def evaluated(self) -> int:
        """Cases where evaluation actually completed (no error/skip)."""
        return sum(1 for r in self.case_results if r.status in EVALUATION_STATUSES)

    @property
    def errors(self) -> int:
        """Cases where evaluation could not complete (model/judge/evaluator/timeout)."""
        return sum(1 for r in self.case_results if r.status in ERROR_STATUSES)

    @property
    def skipped(self) -> int:
        """Cases deliberately skipped (e.g., via tag filter)."""
        return sum(1 for r in self.case_results if r.status == EvalStatus.SKIPPED)

    @property
    def error_rate(self) -> float:
        """Fraction of ALL cases that errored (model/judge/evaluator/timeout).

        Denominator is ``total``, not ``evaluated`` — this is the metric
        ``pass_rate`` is blind to by design, so the two must be read together.
        """
        return self.errors / self.total if self.total else 0.0

    @property
    def errors_by_kind(self) -> dict[str, int]:
        """Breakdown of error cases by status — model_error vs judge_error etc."""
        counts: dict[str, int] = {}
        for r in self.case_results:
            if r.status in ERROR_STATUSES:
                counts[r.status.value] = counts.get(r.status.value, 0) + 1
        return counts

    @property
    def passed(self) -> int:
        return sum(1 for r in self.case_results if r.status == EvalStatus.PASSED)

    @property
    def failed(self) -> int:
        """Cases that completed evaluation and failed on quality (NOT errors)."""
        return sum(1 for r in self.case_results if r.status == EvalStatus.FAILED_QUALITY)

    @property
    def pass_rate(self) -> float:
        """Fraction of EVALUATED cases that passed.

        Error and skipped cases are excluded from the denominator — a judge
        outage or a crashed model_fn shouldn't be mistaken for a quality
        regression. Use :attr:`errors` to surface infrastructure problems
        independently.
        """
        denom = self.evaluated
        return self.passed / denom if denom else 0.0

    @property
    def avg_score(self) -> float:
        """Average evaluator score across cases that actually evaluated."""
        evaluated = [r for r in self.case_results if r.status in EVALUATION_STATUSES]
        if not evaluated:
            return 0.0
        return sum(r.score for r in evaluated) / len(evaluated)

    @property
    def saturated(self) -> bool:
        """True when every EVALUATED case passed.

        Built on ``evaluated``, not ``total`` — a 100% assembled from judge
        outages or skips must not count as saturation. A saturated suite
        can no longer detect improvement; see
        :attr:`min_detectable_regression` for what it can still claim.
        """
        return self.evaluated > 0 and self.passed == self.evaluated

    @property
    def min_detectable_regression(self) -> float:
        """Smallest pass-rate DROP this suite can detect at 80% power.

        Anchors the variance term near the observed pass rate, capped at
        0.95 — at a true ceiling p(1-p) → 0 would flatter the MDE toward
        zero, promising sensitivity the suite doesn't have. Returns 1.0
        (nothing detectable) when no case evaluated.
        """
        if self.evaluated == 0:
            return 1.0
        from .experiments import min_detectable_effect
        return min_detectable_effect(
            self.evaluated, baseline=max(0.5, min(self.pass_rate, 0.95)),
        )

    @property
    def zero_pass_cases(self) -> list["CaseResult"]:
        """Cases that failed EVERY trial — broken-task/grader suspects.

        With runs > 1: evaluated cases with ``pass_count == 0``. With a
        single run there is no per-case trial signal, so the heuristic
        only fires suite-wide: when ``pass_rate == 0.0`` every evaluated
        (failing) case is suspect. 0% pass usually means a broken task or
        grader, not an incapable agent — ``multivon-eval validate`` checks
        the graders against reference outputs before the model is blamed.
        """
        evaluated = [
            cr for cr in self.case_results if cr.status in EVALUATION_STATUSES
        ]
        multi = [cr for cr in evaluated if cr.runs > 1 and cr.pass_count == 0]
        if multi:
            return multi
        if any(cr.runs > 1 for cr in evaluated):
            return []
        if evaluated and self.pass_rate == 0.0:
            return evaluated
        return []

    @property
    def flaky_count(self) -> int:
        return sum(1 for r in self.case_results if r.is_flaky)

    @property
    def stability_score(self) -> float:
        """Fraction of cases that behave consistently (always pass or always fail)."""
        if not self.case_results:
            return 1.0
        consistent = sum(1 for r in self.case_results if not r.is_flaky)
        return consistent / self.total

    @property
    def runs_per_case(self) -> int:
        """Trials requested per case: the MAX of per-case run counts.

        Per-case counts can differ when ``early_stop`` (SPRT) ends easy
        cases before the requested ``runs`` — max recovers the requested
        count and is case-order independent (this used to read
        ``case_results[0].runs``, so the report changed with case order).
        pass@k / pass^k at this k degrade to an honest UNKNOWN whenever
        any evaluated case recorded fewer trials.
        """
        if self.case_results:
            return max(cr.runs for cr in self.case_results)
        return 1

    @property
    def failed_cases(self) -> list["CaseResult"]:
        """Cases where at least one evaluator failed."""
        return [cr for cr in self.case_results if not cr.passed]

    def assert_budget(
        self,
        *,
        max_total_cost_usd: float | None = None,
        max_avg_cost_per_case_usd: float | None = None,
        max_total_tokens: int | None = None,
        max_p95_latency_ms: float | None = None,
        max_avg_latency_ms: float | None = None,
    ) -> None:
        """Enforce cost / token / latency budgets on the run.

        Raises :class:`EvalGateFailure` (subclass of SystemExit) if any
        provided budget is exceeded — same exit semantics as the existing
        ``suite.run(fail_threshold=...)`` gate, so it works in CI without
        additional plumbing.

        All thresholds are opt-in: pass only the dimensions you want to
        enforce. None == no limit. Built so CFO-level constraints and
        infra-level SLOs (p95 latency) can both be gated in the same call.

        Inspired by Promptfoo's ``cost`` and ``latency`` assertions, but
        scoped to the whole run rather than per-case — cost is a
        cross-call aggregate concern, not a per-evaluator one.
        """
        violations: list[str] = []

        # Cost gates — only enforceable if pricing data is present.
        if (max_total_cost_usd is not None or max_avg_cost_per_case_usd is not None) and self.costs is not None:
            total = self.costs.total_cost_usd
            if total is None:
                violations.append(
                    "Cost budget requested but at least one model lacks pricing data — "
                    "register pricing via multivon_eval.register_pricing() to enable gating."
                )
            else:
                if max_total_cost_usd is not None and total > max_total_cost_usd:
                    violations.append(
                        f"Total cost ${total:.4f} exceeds budget ${max_total_cost_usd:.4f}"
                    )
                if max_avg_cost_per_case_usd is not None and self.total > 0:
                    avg = total / self.total
                    if avg > max_avg_cost_per_case_usd:
                        violations.append(
                            f"Avg cost/case ${avg:.4f} exceeds budget ${max_avg_cost_per_case_usd:.4f}"
                        )

        # Token gates.
        if max_total_tokens is not None and self.costs is not None:
            if self.costs.total_tokens > max_total_tokens:
                violations.append(
                    f"Total tokens {self.costs.total_tokens:,} exceeds budget {max_total_tokens:,}"
                )

        # Latency gates use the per-case CaseResult.latency_ms timing.
        if max_avg_latency_ms is not None or max_p95_latency_ms is not None:
            latencies = sorted(
                cr.latency_ms for cr in self.case_results if cr.latency_ms is not None
            )
            if latencies:
                if max_avg_latency_ms is not None:
                    avg_ms = sum(latencies) / len(latencies)
                    if avg_ms > max_avg_latency_ms:
                        violations.append(
                            f"Avg latency {avg_ms:.0f}ms exceeds budget {max_avg_latency_ms:.0f}ms"
                        )
                if max_p95_latency_ms is not None:
                    # Linear-interpolation p95 (good enough for budget gating).
                    idx = max(0, int(round(0.95 * (len(latencies) - 1))))
                    p95_ms = latencies[idx]
                    if p95_ms > max_p95_latency_ms:
                        violations.append(
                            f"p95 latency {p95_ms:.0f}ms exceeds budget {max_p95_latency_ms:.0f}ms"
                        )

        if violations:
            raise EvalGateFailure(
                "Budget gate FAILED:\n  • " + "\n  • ".join(violations)
            )

    @property
    def passed_cases(self) -> list["CaseResult"]:
        """Cases where all evaluators passed."""
        return [cr for cr in self.case_results if cr.passed]

    def filter_by_evaluator(self, name: str) -> list["CaseResult"]:
        """Cases where the named evaluator failed. Useful for drilling into a specific check."""
        return [
            cr for cr in self.case_results
            if cr.status in EVALUATION_STATUSES
            and any(r.evaluator == name and not r.passed and not r.metadata.get("skipped")
                    for r in cr.results)
        ]

    def sample(self, n: int, *, failed_only: bool = False) -> list["CaseResult"]:
        """
        Random sample of n cases. Pass failed_only=True to sample from failures only.
        Useful for spot-checking a large eval run without reading every result.
        """
        import random
        pool = self.failed_cases if failed_only else self.case_results
        return random.sample(pool, min(n, len(pool)))

    def pass_rate_ci(self, confidence: float = 0.95) -> tuple[float, float]:
        """Wilson score 95% CI on the pass rate.

        Denominator matches :attr:`pass_rate` (``evaluated``) so the CI
        describes the same metric being reported. More reliable than the
        normal approximation for small n.
        """
        from .experiments import wilson_interval
        return wilson_interval(self.passed, self.evaluated, confidence)

    def avg_score_ci(self, confidence: float = 0.95) -> tuple[float, float]:
        """Bootstrap CI on the mean score over evaluated cases (no errors)."""
        from .experiments import bootstrap_interval
        scores = [cr.score for cr in self.case_results if cr.status in EVALUATION_STATUSES]
        return bootstrap_interval(scores, confidence)

    def _pass_k_case_stats(self) -> list[tuple[int, int]]:
        """Per-case (n_trials, n_passes) over EVALUATED cases only.

        Same denominator discipline as :attr:`pass_rate` — error and
        skipped cases are excluded so infrastructure problems don't
        masquerade as reliability signal.
        """
        stats: list[tuple[int, int]] = []
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES:
                continue
            if cr.pass_count >= 0:
                stats.append((cr.runs, cr.pass_count))
            else:
                stats.append((1, 1 if cr.passed else 0))
        return stats

    def _pass_k_result(self, k: int, confidence: float, metric: str) -> "PassKResult":
        """Report-surface pass@k / pass^k. NEVER raises for k > data.

        Per-case run counts can be heterogeneous (early_stop / SPRT ends
        easy cases early). Each case contributes with its own n; a case
        with fewer than k trials cannot contribute without extrapolating,
        so when k exceeds min(n) over the evaluated cases the metric
        degrades to an honest UNKNOWN naming the binding case — it must
        not crash a paid run in the terminal report or to_json().
        Library calls (:func:`passk.pass_at_k` / :func:`passk.pass_hat_k`)
        keep their ValueError; report methods may not raise.
        """
        if k < 1:
            raise ValueError(f"k must be >= 1, got {k}")
        from . import passk
        stats = self._pass_k_case_stats()
        if stats:
            min_n = min(n for n, _ in stats)
            if k > min_n:
                hetero = any(n != min_n for n, _ in stats)
                where = (
                    "the shortest-run case (early_stop)" if hetero
                    else "each case"
                )
                return passk.PassKResult(
                    k=k, metric=metric, value=None, ci_low=None, ci_high=None,
                    estimator=passk.ESTIMATOR_NAMES[metric],
                    n_cases=len(stats), runs=min_n,
                    unknown_reason=(
                        f"UNKNOWN — k={k} exceeds the {min_n} trials of {where}; "
                        f"rerun with --runs >= {k} or pass k <= {min_n}. "
                        f"multivon-eval does not extrapolate."
                    ),
                )
        return passk.suite_pass_k(stats, k, metric=metric, confidence=confidence)

    def pass_at_k(self, k: int, confidence: float = 0.95) -> "PassKResult":
        """pass@k over evaluated cases — "succeeds at least once in k tries".

        Unbiased combinatorial estimator per case (each case uses its own
        recorded trial count), averaged over cases, with a
        cluster-bootstrap CI (cases resampled, not trials). Returns an
        honest UNKNOWN result (``value is None``) when k exceeds the
        trial count of ANY evaluated case (e.g. after ``early_stop``) —
        no extrapolation, and never an exception.
        """
        from .passk import METRIC_PASS_AT_K
        return self._pass_k_result(k, confidence, METRIC_PASS_AT_K)

    def pass_hat_k(self, k: int, confidence: float = 0.95) -> "PassKResult":
        """pass^k over evaluated cases — "succeeds all k tries".

        Exact hypergeometric estimator per case (never the upward-biased
        plug-in ``(c/n)**k``; each case uses its own recorded trial
        count), averaged over cases, with a cluster-bootstrap CI.
        Returns an honest UNKNOWN result when k exceeds the trial count
        of ANY evaluated case (e.g. after ``early_stop``) — never an
        exception.
        """
        from .passk import METRIC_PASS_HAT_K
        return self._pass_k_result(k, confidence, METRIC_PASS_HAT_K)

    def lottery_cases(self, k: int | None = None) -> list["CaseResult"]:
        """Cases driving the pass@k / pass^k gap, largest divergence first.

        These pass sometimes but never reliably — high pass@k, low
        pass^k. ``k`` defaults to ``runs_per_case``.
        """
        from .passk import pass_at_k as _pak, pass_hat_k as _phk
        if k is None:
            k = self.runs_per_case
        if k < 1:
            raise ValueError(f"k must be >= 1, got {k}")
        scored: list[tuple[float, CaseResult]] = []
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES or cr.pass_count < 0:
                continue
            if k > cr.runs:
                continue
            gap = _pak(cr.runs, cr.pass_count, k) - _phk(cr.runs, cr.pass_count, k)
            if gap > 0:
                scored.append((gap, cr))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [cr for _, cr in scored]

    def assert_pass_hat_k(self, k: int, min_ci_low: float) -> None:
        """Gate the run on the pass^k CI LOWER bound.

        Raises :class:`EvalGateFailure` (same CI exit semantics as
        ``fail_threshold`` / ``assert_budget``) when the lower bound
        falls below ``min_ci_low`` — or when pass^k is UNKNOWN (k exceeds
        the recorded trials of some case, e.g. after ``early_stop``): an
        ungateable claim must fail loudly, not silently pass. This is a
        GATE, so it raises on UNKNOWN even though report surfaces
        (terminal / to_json) merely degrade to UNKNOWN.
        """
        res = self.pass_hat_k(k)
        if res.value is None:
            raise EvalGateFailure(
                f"pass^{k} gate FAILED: {res.unknown_reason}",
                threshold=min_ci_low,
            )
        if res.ci_low < min_ci_low:
            raise EvalGateFailure(
                f"pass^{k} gate FAILED: CI lower bound {res.ci_low:.3f} < "
                f"required {min_ci_low:.3f} "
                f"(pass^{k} = {res.value:.3f}, CI [{res.ci_low:.3f}, {res.ci_high:.3f}])",
                pass_rate=res.value, threshold=min_ci_low,
            )

    def score_percentiles(self, percentiles: list[int] | None = None) -> dict[str, float]:
        """
        Score distribution percentiles. Reveals bimodal patterns avg_score hides.

        A model that scores 0.95 or 0.40 (never in between) has the same avg_score
        as one that scores 0.67 consistently — but they behave very differently.

        Args:
            percentiles: Percentile ranks to compute (default [10, 50, 90]).

        Returns:
            Dict like {"p10": 0.41, "p50": 0.82, "p90": 0.96}.
        """
        if percentiles is None:
            percentiles = [10, 50, 90]
        scores = sorted(cr.score for cr in self.case_results
                        if cr.status in EVALUATION_STATUSES)
        if not scores:
            return {}
        n = len(scores)
        result: dict[str, float] = {}
        for p in percentiles:
            idx = (p / 100) * (n - 1)
            lo, hi = int(idx), min(int(idx) + 1, n - 1)
            frac = idx - lo
            val = scores[lo] * (1 - frac) + scores[hi] * frac
            result[f"p{p}"] = round(val, 4)
        return result

    def scores_by_tag(self) -> dict[str, float]:
        """Average score per tag across all tagged cases."""
        totals: dict[str, list[float]] = {}
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES:
                continue
            for tag in cr.tags:
                totals.setdefault(tag, []).append(cr.score)
        return {k: round(sum(v) / len(v), 4) for k, v in totals.items()}

    def passed_by_tag(self) -> dict[str, float]:
        """Pass rate per tag across all tagged cases."""
        totals: dict[str, list[bool]] = {}
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES:
                continue
            for tag in cr.tags:
                totals.setdefault(tag, []).append(cr.passed)
        return {k: round(sum(v) / len(v), 4) for k, v in totals.items()}

    def count_by_tag(self) -> dict[str, int]:
        """Number of cases per tag."""
        counts: dict[str, int] = {}
        for cr in self.case_results:
            for tag in cr.tags:
                counts[tag] = counts.get(tag, 0) + 1
        return counts

    def scores_by_evaluator(self) -> dict[str, float]:
        totals: dict[str, list[float]] = {}
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES:
                continue
            for r in cr.results:
                if not r.metadata.get("skipped"):
                    totals.setdefault(r.evaluator, []).append(r.score)
        return {k: sum(v) / len(v) for k, v in totals.items()}

    def passed_by_evaluator(self) -> dict[str, float]:
        totals: dict[str, list[bool]] = {}
        for cr in self.case_results:
            if cr.status not in EVALUATION_STATUSES:
                continue
            for r in cr.results:
                if not r.metadata.get("skipped"):
                    totals.setdefault(r.evaluator, []).append(r.passed)
        return {k: sum(v) / len(v) for k, v in totals.items()}

    @classmethod
    def from_dict(cls, data: dict) -> "EvalReport":
        """Reconstruct an EvalReport from the dict produced by to_json()."""
        if data.get("schema", "multivon.report/v1") not in {"multivon.report/v1", "multivon.report/v2"}:
            raise ValueError("Unsupported report schema")
        case_results = []
        for c in data.get("cases", []):
            results = [
                EvalResult(
                    evaluator=e["name"],
                    score=e["score"],
                    passed=e["passed"],
                    reason=e.get("reason", ""),
                    metadata=e.get("metadata", {}),
                )
                for e in c.get("evaluators", [])
            ]
            runs = c.get("runs", 1)
            all_scores = c.get("all_scores") or []
            cr = CaseResult(
                case_input=c["input"],
                actual_output=c["output"],
                results=results,
                latency_ms=c.get("latency_ms", 0.0),
                tags=c.get("tags", []),
                model_error=c.get("model_error"),
                judge_error=c.get("judge_error"),
                evaluator_error=c.get("evaluator_error"),
                skipped=c.get("skipped", False),
                runs=runs,
                all_scores=all_scores,
                pass_count=-1,
                retry_attempts=c.get("retry_attempts", 0),
                retry_errors=list(c.get("retry_errors", [])),
                case_id=c.get("case_id"),
                case_digest=c.get("case_digest"),
                agent_trace=trace_from_data(c.get("agent_trace")),
                trials=tuple(TrialRecord.from_dict(t) for t in c.get("trials", [])),
                evidence_error=c.get("evidence_error"),
            )
            if runs > 1:
                rpr = c.get("run_pass_rate", 1.0)
                cr.pass_count = c.get("pass_count", round(rpr * runs))
            case_results.append(cr)
        from .costs import Costs
        from .lockfile import SuiteLock
        summary = data.get("summary") or {}
        return cls(
            suite_name=data.get("suite", ""),
            model_id=data.get("model", ""),
            case_results=case_results,
            purpose=(data.get("summary") or {}).get("purpose", ""),
            judge_reliability=summary.get("judge_reliability"),
            costs=Costs.from_dict(summary["costs"]) if summary.get("costs") is not None else None,
            suite_lock=SuiteLock.from_dict(data["suite_lock"]) if data.get("suite_lock") else None,
            evidence_issues=list(data.get("evidence_issues", [])),
        )

    def to_json(self) -> str:
        def _ser(obj):
            if hasattr(obj, "__dataclass_fields__"):
                return obj.__dict__
            return str(obj)
        summary: dict[str, Any] = {
            "total": self.total,
            "evaluated": self.evaluated,
            "passed": self.passed,
            "failed": self.failed,
            "errors": self.errors,
            "errors_by_kind": self.errors_by_kind,
            "skipped": self.skipped,
            "pass_rate": round(self.pass_rate, 4),
            "pass_rate_ci_95": list(self.pass_rate_ci()),
            "avg_score": round(self.avg_score, 4),
            "avg_score_ci_95": list(self.avg_score_ci()),
            "score_percentiles": self.score_percentiles(),
            "runs_per_case": self.runs_per_case,
            "flaky_count": self.flaky_count,
            "stability_score": round(self.stability_score, 4),
            "judge_reliability": self.judge_reliability,
            "purpose": self.purpose,
            "saturated": self.saturated,
            "min_detectable_regression": round(self.min_detectable_regression, 4),
            "by_evaluator": {k: round(v, 4) for k, v in self.scores_by_evaluator().items()},
            "costs": self.costs.to_dict() if self.costs is not None else None,
        }
        if self.runs_per_case > 1:
            k = self.runs_per_case
            for key, res in (("pass_at_k", self.pass_at_k(k)),
                             ("pass_hat_k", self.pass_hat_k(k))):
                summary[key] = {
                    "k": res.k,
                    "value": round(res.value, 4) if res.value is not None else None,
                    "ci_95": (
                        [round(res.ci_low, 4), round(res.ci_high, 4)]
                        if res.ci_low is not None else None
                    ),
                    "estimator": res.estimator,
                    "runs": res.runs,
                }
                if res.value is None:
                    summary[key]["unknown_reason"] = res.unknown_reason
        return json.dumps(
            {
                "schema": "multivon.report/v2",
                "evidence_issues": self.evidence_issues,
                "suite": self.suite_name,
                "model": self.model_id,
                "suite_lock": self.suite_lock.to_dict() if self.suite_lock is not None else None,
                "summary": summary,
                "cases": [
                    {
                        "input": cr.case_input,
                        "case_id": cr.case_id,
                        "case_digest": cr.case_digest,
                        "agent_trace": trace_to_data(cr.agent_trace),
                        "trials": [t.data for t in cr.trials],
                        "evidence_error": cr.evidence_error,
                        "output": cr.actual_output,
                        "status": cr.status.value,
                        "model_error": cr.model_error,
                        "judge_error": cr.judge_error,
                        "evaluator_error": cr.evaluator_error,
                        "skipped": cr.status == EvalStatus.SKIPPED,
                        "passed": cr.passed,
                        "score": round(cr.score, 4),
                        "score_std": round(cr.score_std, 4),
                        "all_scores": cr.all_scores,
                        "run_pass_rate": round(cr.run_pass_rate, 4),
                        "is_flaky": cr.is_flaky,
                        "runs": cr.runs,
                        "pass_count": cr.pass_count,
                        "retry_attempts": cr.retry_attempts,
                        "retry_errors": cr.retry_errors,
                        "latency_ms": round(cr.latency_ms, 1),
                        "tags": cr.tags,
                        "evaluators": [
                            {
                                "name": r.evaluator,
                                "score": round(r.score, 4),
                                "passed": r.passed,
                                "reason": r.reason,
                                "metadata": r.metadata,
                            }
                            for r in cr.results
                        ],
                    }
                    for cr in self.case_results
                ],
            },
            default=_ser,
            indent=2,
        )

    def save_json(self, path: str) -> None:
        # Auto-create parent dir so callers don't have to `os.makedirs` first.
        # Common path is `suite.run(save_json="eval-reports/x.json")` on a
        # fresh checkout — the directory doesn't exist yet and the user just
        # got a stack trace right after their first successful eval run.
        import os
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w") as f:
            f.write(self.to_json())

    def compare(self, other: "EvalReport") -> "Any":
        """Diff this report (as baseline) against ``other`` (proposal).

        Returns a :class:`multivon_eval.compare.ReportDiff` with pass-rate
        and avg-score deltas, per-case regressions / improvements
        (paired by ``case_input``), and a McNemar p-value over paired
        cases. See ``multivon_eval.compare`` for the full API."""
        from .compare import compare_reports
        return compare_reports(self, other)

    def to_html(self) -> str:
        """Return a self-contained HTML report string."""
        from .reporters.html import to_html as _to_html
        return _to_html(self)

    def save_html(self, path: str) -> None:
        """Write the HTML report to path."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_html())

    def to_junit_xml(self) -> str:
        """Render the report as JUnit XML.

        GitHub Actions, GitLab CI, CircleCI, Jenkins, and most other CI
        systems render JUnit XML natively in their PR/job summary UI —
        producing one of these alongside the JSON report makes eval
        failures show up in the CI's structured test panel.

        Mapping (per JUnit conventions):
          - Suite: the multivon-eval suite. One ``<testsuite>``.
          - Test case: each (case, evaluator) pair. One ``<testcase>``.
          - Pass/fail: a passing evaluator emits a bare ``<testcase>``;
            a failing one (or a failed-quality case where no specific
            evaluator was the proximate cause) emits ``<failure>``; an
            error case (model crashed, judge unavailable) emits
            ``<error>``; a deliberately skipped case emits ``<skipped>``.

        The string returned is ready to drop into a CI artifact path
        (e.g., ``junit.xml``).
        """
        from xml.etree.ElementTree import Element, SubElement, tostring

        def _classify_row(cr: "CaseResult") -> str:
            """Return the JUnit verb for one (case, evaluator) row.

            One of: 'passed', 'failed', 'errored', 'skipped'. Status
            (the case-level outcome) dominates over the per-evaluator
            passed flag.
            """
            if cr.status == EvalStatus.SKIPPED:
                return "skipped"
            if cr.status in ERROR_STATUSES:
                return "errored"
            if cr.status == EvalStatus.FAILED_QUALITY:
                # In a multi-run aggregate, the per-evaluator EvalResult.passed
                # reflects the MAJORITY vote across runs. The case as a whole
                # can still be FAILED_QUALITY (pass_count < runs) even if the
                # majority on every evaluator was "passed". The CI consumer
                # must still see a failure somewhere — emit failure on every
                # row in this case.
                return "failed"
            return "passed"

        rows: list[tuple[CaseResult, EvalResult | None, str]] = []
        for cr in self.case_results:
            # An error case with no evaluator results still emits one row so
            # the CI sees the case at all.
            for r in (cr.results or [None]):
                verb = _classify_row(cr)
                if r is not None and r.metadata.get("skipped") and verb != "errored":
                    verb = "skipped"
                rows.append((cr, r, verb))

        total_tests = len(rows)
        n_failures = sum(1 for _, _, v in rows if v == "failed")
        n_errors = sum(1 for _, _, v in rows if v == "errored")
        n_skipped = sum(1 for _, _, v in rows if v == "skipped")
        suite_time = sum(cr.latency_ms for cr in self.case_results) / 1000.0

        ts = Element("testsuites")
        suite_el = SubElement(ts, "testsuite", {
            "name": _xml_safe(self.suite_name or "multivon-eval"),
            "tests": str(total_tests),
            "failures": str(n_failures),
            "errors": str(n_errors),
            "skipped": str(n_skipped),
            "time": f"{suite_time:.3f}",
        })

        for cr, r, verb in rows:
            classname = _xml_safe(self.suite_name or "multivon-eval")
            ev_name = _xml_safe(r.evaluator) if r is not None else "(case-level)"
            input_excerpt = _xml_safe((cr.case_input or "")[:80])
            tc = SubElement(suite_el, "testcase", {
                "classname": classname,
                "name": f"{ev_name} :: {input_excerpt}",
                "time": f"{cr.latency_ms / 1000.0:.3f}",
            })

            if verb == "passed":
                continue
            if verb == "skipped":
                SubElement(tc, "skipped", {"message": "case marked skipped"})
                continue
            if verb == "errored":
                detail = (
                    cr.model_error or cr.judge_error or cr.evaluator_error or
                    (r.reason if r is not None else "") or "error"
                )
                # ElementTree handles XML escaping on serialization; pass raw
                # text. Pre-escaping it would double-encode and render
                # &lt;script&gt; literally in CI output.
                node = SubElement(tc, "error", {
                    "type": cr.status.value,
                    "message": _xml_safe(detail[:200] if detail else "error"),
                })
                node.text = _xml_safe(detail or "")
                continue
            # verb == "failed"
            if r is not None and not r.passed:
                msg = r.reason or "evaluator failed"
                node = SubElement(tc, "failure", {
                    "type": "quality",
                    "message": _xml_safe(msg[:200]),
                })
                node.text = _xml_safe(r.reason or "")
            else:
                # Aggregate failed-quality case (no specific evaluator failed
                # this row, but the case as a whole failed). Emit a failure
                # so the CI surfaces it — otherwise the row looks passing
                # while the suite-level failure count says otherwise.
                node = SubElement(tc, "failure", {
                    "type": "quality",
                    "message": "case failed quality bar",
                })
                node.text = _xml_safe("case status=FAILED_QUALITY (aggregate)")

        return '<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(ts, encoding="unicode")

    def save_junit_xml(self, path: str) -> None:
        """Write the JUnit XML report to ``path``."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_junit_xml())

    def save_csv(self, path: str) -> None:
        rows = []
        for cr in self.case_results:
            for r in cr.results:
                rows.append({
                    "input": cr.case_input[:200],
                    "output": cr.actual_output[:200],
                    "evaluator": r.evaluator,
                    "score": round(r.score, 4),
                    "score_std": round(cr.score_std, 4),
                    "run_pass_rate": round(cr.run_pass_rate, 4),
                    "is_flaky": cr.is_flaky,
                    "passed": r.passed,
                    "reason": r.reason[:300],
                    "latency_ms": round(cr.latency_ms, 1),
                    "tags": ",".join(cr.tags),
                })
        with open(path, "w", newline="") as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
