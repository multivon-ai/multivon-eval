import asyncio,json
from pathlib import Path
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters,stdio_client
from multivon_eval import AcceptancePolicy,CheckRequirement
root=Path('/tmp/multivon-world-heldout-01')
async def main():
 params=StdioServerParameters(command='/tmp/multivon-companion-release-312/bin/python',args=['-m','multivon_mcp.server'],cwd='/tmp')
 observed=[]
 async with stdio_client(params) as (reader,writer), ClientSession(reader,writer) as session:
  server=await session.initialize()
  for model,horizon in [('action_conditioned',1),('action_blind',1),('action_conditioned',32)]:
   field='cart_velocity' if horizon==1 else 'pole_angle'
   policy=AcceptancePolicy((CheckRequirement(f'dynamics/{field}/h{horizon}',min_cases=40),),min_source_groups=40,min_cases=40)
   policy_path=root/f'posthoc-policy-{model}-h{horizon}.json';policy_path.write_text(json.dumps(policy.to_dict()))
   result=await session.call_tool('eval_acceptance_report',{'report_json_path':str(root/f'report-{model}.json'),'policy_json_path':str(policy_path)})
   data=result.model_dump(mode='json')
   observed.append({'model':model,'horizon':horizon,'result':data})
  (root/'mcp-posthoc-interop.json').write_text(json.dumps({'server':server.model_dump(mode='json'),'server_cwd':'/tmp','published_core':'0.18.0','published_mcp':'0.4.0','purpose':'Post-hoc transport/coverage checks, not frozen release acceptance','calls':observed},indent=2)+'\n')
  for item in observed:
   print(item['model'],item['horizon'],str(item['result'])[:450])
asyncio.run(main())
